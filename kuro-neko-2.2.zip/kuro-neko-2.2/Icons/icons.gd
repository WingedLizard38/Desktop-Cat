extends Window

@onready var main := get_parent()

@export var base_offset:Vector2i
@onready var offset := position

@export var outline_mat:ShaderMaterial

@export var settings:Window
@export var exit:Window
@export var notes:Window

func _ready():
	close_window()

func open_window():
	show()

func close_window():
	if !exit.visible : # No exit promt on the screen
		hide()
		settings.hide()
		notes.hide()
		
		main.frozen = false

func open_settings():
	if settings.visible: # Close 
		settings.close_window()
	else: # Open
		settings.open_window()

func close_application():
	hide()
	exit.open_window()

func _process(delta): 
	if visible:
		# Follow Main Window
		position = DisplayServer.window_get_position() + offset
