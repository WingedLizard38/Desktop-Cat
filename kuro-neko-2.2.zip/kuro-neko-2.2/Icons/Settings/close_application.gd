extends Window

@export var icons:Window
@export var settings:Window

func _ready():
	hide()

func open_window():
	show()
	var m_pos = DisplayServer.mouse_get_position()
	if m_pos.x + size.x > DisplayServer.screen_get_size().x:
		m_pos.x = DisplayServer.screen_get_size().x - size.x
	position = m_pos

func exit():
	get_tree().quit()

func return_to_menu():
	hide()
