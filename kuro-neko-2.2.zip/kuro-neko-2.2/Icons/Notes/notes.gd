extends Window

@export var icons:Window

var last_position:Vector2

func _ready():
	hide()

func open_window():
	if !visible: # Open
		if last_position: position = last_position # If there is a past position saved
		else: position = Vector2(10, 50)
		show()
	else: # Hide
		return_to_menu()

func return_to_menu():
	last_position = position # Save current position for later
	hide()
	icons.open_window()
