extends TextureButton

var mouse_inside := 0

var target_stretch_ratio := 1.0

func _ready():
	mouse_entered.connect(_on_mouse_entered)
	mouse_exited.connect(_on_mouse_exited)

func _process(delta):
	if mouse_inside > 0:
		target_stretch_ratio = 1.15
	else:
		target_stretch_ratio = 1.0
	
	if visible:
		size_flags_stretch_ratio = lerp(size_flags_stretch_ratio, target_stretch_ratio, delta * 14)
		if abs(target_stretch_ratio - size_flags_stretch_ratio) < 0.05:
			size_flags_stretch_ratio = target_stretch_ratio
	else:
		target_stretch_ratio = 1.0
		reset_scale()

func _on_mouse_entered():
	mouse_inside += 1

func _on_mouse_exited():
	await get_tree().create_timer(0.1).timeout
	mouse_inside -= 1

func reset_scale():
	target_stretch_ratio = 1.0
	size_flags_stretch_ratio = 1.0
