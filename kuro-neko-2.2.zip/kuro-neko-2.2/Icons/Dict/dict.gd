extends Window

@export var title_box:LineEdit
@export var tag_box:LineEdit
@export var content_box:TextEdit


@export var search_box:LineEdit
@export var item_list:ItemList

var selected:int = -1

var list:Array = []

# Connect the visual list indicies to the actual stored list 
#(Searching messes this up)
var references:Array = []

class page:
	var page_name:String = "New Entry"
	var tags:String = ""
	var content:String = ""

func _ready():
	hide()

func toggle_window():
	if !visible:
		show()
	else:
		hide()

func close_window():
	hide()

func move_page_up():
	# Not searching, not empty, not the first page
	if search_box.text == "" and selected != -1 and selected != 0: 
		var temp = list[selected-1]
		list[selected-1] = list[selected]
		list[selected] = temp
		
		selected -= 1
	
		exact_search("") # Reload page

func move_page_down():
	if search_box.text == "" and selected != -1 and selected != list.size() - 1:
		var temp = list[selected+1]
		list[selected+1] = list[selected]
		list[selected] = temp
		
		selected += 1
	
		exact_search("") # Reload page

func set_page_num(index:int):
	selected = index
	open_page_reference()

func set_empty_page(_postion:Vector2, _mb:int):
	selected = -1
	open_page_reference()

func new_page():
	var new = page.new()
	list.append(new)
	
	selected = list.size() - 1
	open_page_direct()
	
	item_list.add_item("New Entry")
	
	exact_search(search_box.text) # Refresh shown pages

func delete_page():
	if selected != -1: # Not empty page
		list.remove_at(references[selected])
		selected = -1
		open_page_reference()
		
		exact_search(search_box.text) # Refresh shown pages

func update_title(input:String):
	# Not empty page
	if selected == -1: 
		return
	list[selected].page_name = input
	item_list.set_item_text(selected, input)

func update_tags(input:String):
	# Not empty page
	if selected == -1: 
		return
	list[selected].tags = input

func update_content():
	# Not empty page
	if selected == -1: 
		return
	list[selected].content = content_box.text

func open_page_direct():
	title_box.text = list[selected].page_name
	tag_box.text = list[selected].tags
	content_box.text = list[selected].content

func open_page_reference():
	if selected == -1: # Empty
		title_box.text = ""
		tag_box.text = ""
		content_box.text = ""
	else:
		title_box.text = list[references[selected]].page_name
		tag_box.text = list[references[selected]].tags
		content_box.text = list[references[selected]].content

func exact_search(search:String):
	item_list.clear()
	references.clear()
	
	for i in range(list.size()):
		var _page = list[i]
		if _page.page_name.containsn(search) or _page.tags.containsn(search) or search == "":
			item_list.add_item(_page.page_name)
			references.append(i) # Appends actual index at the location of visual list index
