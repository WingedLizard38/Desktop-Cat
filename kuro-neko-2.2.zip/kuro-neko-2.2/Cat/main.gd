extends Node2D

var win_pos: Vector2
var velocity = Vector2(1,1)

var screen_size = Vector2()
##Dimensions of the image (Only works properly when square)
@export var image_size = Vector2i(370, 370)
var actual_size = 0

var is_dragging = false
var drag_offset = Vector2()
var idle_timer = 0.0

@onready var main_window := get_window()

var smallest_side
## Character will take up 1/char_size of the screen
@export var char_size = 15:
	set(value):
		char_size = value
		if ready_: recaluculate_effects()

var desired_size 
var scale_multi
var new_side_length 

var ready_ = false # True once the ready function has run

@onready var viewport = $SubViewport
@onready var sprite = $SubViewport/Char
@onready var area = $Area2D


## Turn on outlines
@export var outline_weight = 5:
	set(value):
		outline_weight = value
		
		notify_property_list_changed()
		if ready_: recaluculate_effects()


@export var cup:Sprite2D # Cup has its own hue shift code stored in _ready
@export var rainbow = false:
	set(value):
		rainbow = value
		
		if ready_: _ready(); cup._ready()

@export var rainbow_shader:ShaderMaterial

@onready var icons = $Icons
@onready var icon_base_window_size = icons.size

var frozen = false: # Prevents movement when menu is open
	set(value):
		frozen = value
		if frozen: # Find where the window should be to make room for icons
			var current_pos = main_window.position
			
			var edge_offset_x = icons.size.x + icons.offset.x
			var edge_offset_y_top = icons.offset.y - 15 * scale_multi
			var edge_offset_y_bottom = new_side_length + 30 * scale_multi
			
			if edge_offset_x + current_pos.x > screen_size.x:
				frozen_target_pos.x = screen_size.x - edge_offset_x
				print(frozen_target_pos.x)
			else:
				frozen_target_pos.x = current_pos.x
			
			if current_pos.y + edge_offset_y_top < 0: # Above the screen
				frozen_target_pos.y = -edge_offset_y_top
			else:
				frozen_target_pos.y = current_pos.y
			
			if current_pos.y + edge_offset_y_bottom > screen_size.y:
				frozen_target_pos.y = screen_size.y - edge_offset_y_bottom
				
var frozen_target_pos: Vector2i # Moves toward this position to make space for icons
@export var popup_menu:Window

func _ready(): # Also called when one of these vars is updated
	ready_ = true
	recaluculate_effects()

func recaluculate_effects():
	#region Rainbow Textures
	if rainbow:
		sprite.material = rainbow_shader # cat
		sprite.get_child(6).material = rainbow_shader # eyes
		sprite.get_child(1).material = rainbow_shader # ears and tail
		sprite.get_child(2).material = rainbow_shader
		sprite.get_child(3).material = rainbow_shader
	else:
		sprite.material = null # cat
		sprite.get_child(6).material = null # eyes
		sprite.get_child(1).material = null # ears and tail
		sprite.get_child(2).material = null
		sprite.get_child(3).material = null
	#endregion
	
	screen_size = Vector2(DisplayServer.screen_get_size())
	win_pos = Vector2(main_window.position)
	
	# Pick smallest dimension
	smallest_side = screen_size[0]
	if screen_size[1] < screen_size[0]: smallest_side = screen_size[1]
	
	desired_size = smallest_side / char_size
	scale_multi = desired_size/image_size.x
	if scale_multi == 0: # Image was too large to divide - ignore pixel perfect
		scale_multi = desired_size/image_size.x
	
	new_side_length = scale_multi*image_size.x
	# Needs to be integers due to issues with rounding and detecting when to bounce
	actual_size = Vector2i(new_side_length, new_side_length)
	
	# Resize sprite
	sprite.scale = Vector2(scale_multi, scale_multi)
	# Sprite outline
	$Render.material.set_shader_parameter("line_thickness", outline_weight * scale_multi)
	#Resize icon
	icons.size = Vector2i(icon_base_window_size * scale_multi)
	icons.offset = Vector2i(icons.base_offset * scale_multi)
	icons.outline_mat.set_shader_parameter("line_thickness", outline_weight)
	
	# Resize the collision box (Its also centered so)
	area.get_child(0).shape.size = Vector2(new_side_length, new_side_length)
	var middle = int(new_side_length/2)
	area.get_child(0).position = Vector2(middle, middle)
	
	# Resize viewports
	get_window().size = Vector2(new_side_length, new_side_length)
	viewport.size = Vector2(new_side_length, new_side_length)

func _physics_process(delta):
	win_pos += velocity * delta # Add velocity to position
	
	if frozen: # Skip everything else
		if is_dragging: # Dragging while frozen is rigid
			frozen_target_pos = Vector2(DisplayServer.mouse_get_position()) - drag_offset
		
		# Clamp position to screen
		frozen_target_pos.x = clamp(frozen_target_pos.x, 0, screen_size.x - actual_size.x)
		frozen_target_pos.y = clamp(frozen_target_pos.y, 0, screen_size.y - actual_size.y)
		
		# Move window
		main_window.position = lerp(Vector2(main_window.position), Vector2(frozen_target_pos), delta * 6)
		
		# Set win_pos too so the position doesnt change when menu is closed
		win_pos = main_window.position
		
		return
	
	if is_dragging and !frozen:
		var mouse_pos = Vector2(DisplayServer.mouse_get_position())
		velocity = (mouse_pos - drag_offset - win_pos)
		win_pos = lerp(win_pos, mouse_pos - drag_offset, delta * 10)
	elif velocity.length() < image_size.x/3: # Moving too slow
		velocity = Vector2.ZERO
		main_window.position = Vector2i(win_pos)
		# return later
	
	# Clamp position to screen
	win_pos.x = clamp(win_pos.x, 0, screen_size.x - actual_size.x)
	win_pos.y = clamp(win_pos.y, 0, screen_size.y - actual_size.y)
	
	# Move window
	main_window.position = win_pos

	# Bounce
	if win_pos.x == 0 or win_pos.x >= screen_size.x - actual_size.x:
		velocity.x *= -1
	if win_pos.y == 0 or win_pos.y >= screen_size.y - actual_size.y:
		velocity.y *= -1
	
	# Friction 
	velocity = lerp(velocity, velocity.normalized() * Vector2(image_size.x/3, image_size.x/3) * 2, delta/7)

func _on_area_input(_viewport, event, _shape_idx):
	if event is InputEventMouseButton and event.pressed: # Left click to drag
		if event.button_index == MOUSE_BUTTON_LEFT and !is_dragging:
			is_dragging = true
			var mouse_pos = Vector2(DisplayServer.mouse_get_position())
			win_pos = Vector2(main_window.position)
			drag_offset = mouse_pos - win_pos
		elif event.button_index == MOUSE_BUTTON_RIGHT and !is_dragging: # Right click to open/close menu
			frozen = !frozen
			if frozen: icons.open_window()
			else: icons.close_window()

func _input(event): # Makes sure the mouse is released even when mouse is not in the hitbox
	if event is InputEventMouseButton and !event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT and is_dragging:
			win_pos = Vector2(main_window.position)
			velocity *= 3
			is_dragging = false
